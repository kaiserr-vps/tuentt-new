<?php
$id  = '5234143028';
$key = '5149722117:AAEH8K-5FkjDw00N_WUo6UvgkNJ3eXhyuKc';
$out = "";
$flood = true;
?>